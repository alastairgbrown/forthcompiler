
#if (pass == 0) {
   /* macros */
   #define zero2 { #if (DATAPATH > 16) { psh; psh; xor; swp; and; } #if (DATAPATH <= 16) { psh 0; psh; } }
   #define zero { #if (DATAPATH > 16) { psh; psh; xor; pop; } #if (DATAPATH <= 16) { psh 0; } }
   #define pop2 { pop; pop; }
   #define load n { #if (argc > 0) { psh n; } ld; }
   #define store a, n { #if (argc > 1) { psh n; } #if (argc > 0) { psh a; } st; pop2; }
   #define pushc { zero2; adc; pop; }
   #define popc { psh; lsr; pop2; }
   #define tor { load __sp; psh 1; add; lit __sp; st; swp; pop; store; }
   #define rto { load __sp; ld; load __sp; psh 1; sub; lit __sp; store; }
   /* rename some opcodes */

   /* math functions */
   #define incv v { load v; psh 1; add; lit v; store; }
   #define decv v { load v; psh 1; sub; lit v; store; }
   
   /* program flow control */
   #define jp n { psh n; jnz; flush_opcodes; }
   #define jpnz n { psh; zeq; swp; zeq; lit n; and; pop; jnz; }
   #define jpz n { psh; zeq; lit n; and; pop; jnz; }
   #define js n { psh n; cnz; }
   #define ret { jnz; flush_opcodes; }
   #define reti { swp; swp; ret; }
   #define jpeq n { xor; pop; jpz n; }
   #define jpneq n { xor; pop; jpnz n; }
   #define jplt n { sub; pushc; jpz n; }
   #define jpgte n { sub; pop2; pushc; jpnz n; }
   #define djnz n { psh 1; sub; pop; psh; jpnz n; pop; }
   #define jpnc n { zero2; adc; swp; zeq; lit n; and; pop; jnz; }
   
   #define shr n { psh; i=0; while (i<n) {i=i+1; swp; lsr; } pop; }
   #define shl n { i=0; while (i<n) { i=i+1; psh; add; pop; } }
}
