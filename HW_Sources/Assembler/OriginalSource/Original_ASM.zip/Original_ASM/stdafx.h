#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>
#include <afxtempl.h>
#include <afxcview.h>
#include <afxdao.h>
#include <afxctl.h>
